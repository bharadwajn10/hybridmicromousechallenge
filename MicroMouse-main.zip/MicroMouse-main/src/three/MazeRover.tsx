import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { WAYPOINTS, cellToWorld } from './mazeData';

interface RoverRef {
  group: THREE.Group;
  wheels: THREE.Mesh[];
  sensors: THREE.PointLight[];
  bodyMat: THREE.MeshStandardMaterial;
}

const ROVER_SPEED = 3.5; // units per second
const TURN_LERP = 4.0; // how fast to interpolate rotation
const WHEEL_RADIUS = 0.18;

export default function MazeRover() {
  const groupRef = useRef<THREE.Group>(null);
  const wheelRefs = useRef<THREE.Mesh[]>([]);
  const sensorRefs = useRef<THREE.PointLight[]>([]);
  const bodyMatRef = useRef<THREE.MeshStandardMaterial>(null);

  // Convert waypoints to world coordinates
  const worldWaypoints = useMemo(() => {
    return WAYPOINTS.map(([col, row]) => cellToWorld(col, row));
  }, []);

  // Animation state - use refs to persist across frames
  const stateRef = useRef({
    currentIdx: 0,
    nextIdx: 1,
    progress: 0, // 0 to 1 between current and next waypoint
    currentPos: new THREE.Vector3(worldWaypoints[0][0], 0, worldWaypoints[0][1]),
    currentRotY: 0,
    targetRotY: 0,
    wheelSpin: 0,
    suspensionPhase: 0,
  });

  useFrame((_, rawDelta) => {
    const delta = Math.min(rawDelta, 0.05); // clamp delta to prevent jumps
    const s = stateRef.current;
    const group = groupRef.current;
    if (!group) return;

    const currentWP = worldWaypoints[s.currentIdx];
    const nextWP = worldWaypoints[s.nextIdx];

    const dx = nextWP[0] - currentWP[0];
    const dz = nextWP[1] - currentWP[1];
    const segmentLength = Math.sqrt(dx * dx + dz * dz);

    // Advance progress
    const distanceThisFrame = ROVER_SPEED * delta;
    s.progress += distanceThisFrame / segmentLength;

    // Handle reaching next waypoint
    while (s.progress >= 1) {
      s.progress -= 1;
      s.currentIdx = s.nextIdx;
      s.nextIdx = (s.nextIdx + 1) % worldWaypoints.length;

      const newCurrent = worldWaypoints[s.currentIdx];
      const newNext = worldWaypoints[s.nextIdx];
      const newDx = newNext[0] - newCurrent[0];
      const newDz = newNext[1] - newCurrent[1];
      s.currentPos.set(
        newCurrent[0] + (newNext[0] - newCurrent[0]) * s.progress,
        0,
        newCurrent[1] + (newNext[1] - newCurrent[1]) * s.progress
      );

      // Calculate target rotation for new segment
      s.targetRotY = Math.atan2(newDx, newDz);
      break;
    }

    // Interpolate position along current segment
    const curWP = worldWaypoints[s.currentIdx];
    const nxtWP = worldWaypoints[s.nextIdx];
    s.currentPos.x = curWP[0] + (nxtWP[0] - curWP[0]) * s.progress;
    s.currentPos.z = curWP[1] + (nxtWP[1] - curWP[1]) * s.progress;

    // Update target rotation based on current segment direction
    const segDx = nxtWP[0] - curWP[0];
    const segDz = nxtWP[1] - curWP[1];
    s.targetRotY = Math.atan2(segDx, segDz);

    // Smoothly interpolate rotation towards target (shortest angular path)
    let rotDiff = s.targetRotY - s.currentRotY;
    while (rotDiff > Math.PI) rotDiff -= Math.PI * 2;
    while (rotDiff < -Math.PI) rotDiff += Math.PI * 2;
    s.currentRotY += rotDiff * Math.min(1, TURN_LERP * delta);

    // Apply position and rotation to group
    // Subtle suspension bobbing
    s.suspensionPhase += delta * 4;
    const bob = Math.sin(s.suspensionPhase) * 0.015;

    group.position.set(s.currentPos.x, 0.35 + bob, s.currentPos.z);
    group.rotation.y = s.currentRotY;

    // Rotate wheels based on movement speed
    const wheelRotDelta = (ROVER_SPEED * delta) / WHEEL_RADIUS;
    s.wheelSpin += wheelRotDelta;
    wheelRefs.current.forEach((wheel) => {
      if (wheel) wheel.rotation.x = s.wheelSpin;
    });

    // Pulse sensor lights
    const pulse = 0.8 + Math.sin(s.suspensionPhase * 1.5) * 0.2;
    sensorRefs.current.forEach((light) => {
      if (light) light.intensity = pulse * 2;
    });

    // Subtle body material shimmer
    if (bodyMatRef.current) {
      bodyMatRef.current.emissiveIntensity = 0.15 + Math.sin(s.suspensionPhase * 0.8) * 0.05;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Chassis base - low metallic body */}
      <mesh castShadow position={[0, 0, 0]}>
        <boxGeometry args={[0.7, 0.18, 0.9]} />
        <meshStandardMaterial
          ref={bodyMatRef}
          color={0x1a1a2e}
          metalness={0.9}
          roughness={0.25}
          emissive={0x0044aa}
          emissiveIntensity={0.15}
        />
      </mesh>

      {/* Upper body - angled racing rover shape */}
      <mesh castShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[0.55, 0.12, 0.7]} />
        <meshStandardMaterial
          color={0x0d0d1a}
          metalness={0.85}
          roughness={0.3}
        />
      </mesh>

      {/* Top sensor array */}
      <mesh position={[0, 0.22, 0]}>
        <boxGeometry args={[0.3, 0.06, 0.25]} />
        <meshStandardMaterial
          color={0x222244}
          metalness={0.7}
          roughness={0.4}
          emissive={0x0066ff}
          emissiveIntensity={0.3}
        />
      </mesh>

      {/* Front sensor LED bar */}
      <mesh position={[0, 0.12, 0.38]}>
        <boxGeometry args={[0.4, 0.04, 0.02]} />
        <meshStandardMaterial
          color={0x00aaff}
          emissive={0x00aaff}
          emissiveIntensity={2}
          metalness={0.5}
          roughness={0.2}
        />
      </mesh>

      {/* Front sensor point lights */}
      <pointLight
        ref={(el) => { if (el) sensorRefs.current[0] = el; }}
        position={[-0.15, 0.12, 0.4]}
        color={0x00aaff}
        intensity={2}
        distance={1.5}
      />
      <pointLight
        ref={(el) => { if (el) sensorRefs.current[1] = el; }}
        position={[0.15, 0.12, 0.4]}
        color={0x00aaff}
        intensity={2}
        distance={1.5}
      />

      {/* Rear LED strip */}
      <mesh position={[0, 0.1, -0.38]}>
        <boxGeometry args={[0.35, 0.03, 0.02]} />
        <meshStandardMaterial
          color={0x0044ff}
          emissive={0x0044ff}
          emissiveIntensity={1.5}
        />
      </mesh>

      {/* Wheels - 4 wheels with thick tread */}
      {[
        [0.4, -0.05, 0.3],
        [-0.4, -0.05, 0.3],
        [0.4, -0.05, -0.3],
        [-0.4, -0.05, -0.3],
      ].map((pos, i) => (
        <group key={i} position={pos as [number, number, number]}>
          <mesh
            ref={(el) => { if (el) wheelRefs.current[i] = el; }}
            castShadow
            rotation={[0, 0, Math.PI / 2]}
          >
            <cylinderGeometry args={[WHEEL_RADIUS, WHEEL_RADIUS, 0.12, 20]} />
            <meshStandardMaterial
              color={0x111111}
              metalness={0.4}
              roughness={0.8}
            />
          </mesh>
          {/* Wheel hub with blue accent */}
          <mesh rotation={[0, 0, Math.PI / 2]} position={[0, 0.06, 0]}>
            <cylinderGeometry args={[0.07, 0.07, 0.14, 16]} />
            <meshStandardMaterial
              color={0x334466}
              metalness={0.8}
              roughness={0.3}
              emissive={0x0044aa}
              emissiveIntensity={0.2}
            />
          </mesh>
        </group>
      ))}

      {/* Antenna */}
      <mesh position={[0, 0.35, -0.2]}>
        <cylinderGeometry args={[0.012, 0.012, 0.25, 8]} />
        <meshStandardMaterial color={0x666688} metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.48, -0.2]}>
        <sphereGeometry args={[0.03, 8, 8]} />
        <meshStandardMaterial
          color={0x00aaff}
          emissive={0x00aaff}
          emissiveIntensity={3}
        />
      </mesh>
    </group>
  );
}
