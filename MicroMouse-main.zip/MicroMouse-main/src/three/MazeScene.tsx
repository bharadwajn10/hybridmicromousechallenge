import { useMemo, useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import {
  MAZE_GRID,
  CELL_SIZE,
  GRID_COLS,
  GRID_ROWS,
} from './mazeData';
import MazeRover from './MazeRover';

function MazeWalls() {
  const wallPositions = useMemo(() => {
    const positions: { pos: [number, number, number]; size: [number, number, number] }[] = [];
    for (let row = 0; row < GRID_ROWS; row++) {
      for (let col = 0; col < GRID_COLS; col++) {
        if (MAZE_GRID[row][col] === 1) {
          const x = (col - (GRID_COLS - 1) / 2) * CELL_SIZE;
          const z = (row - (GRID_ROWS - 1) / 2) * CELL_SIZE;
          positions.push({
            pos: [x, 0.5, z],
            size: [CELL_SIZE, 1.0, CELL_SIZE],
          });
        }
      }
    }
    return positions;
  }, []);

  return (
    <group>
      {wallPositions.map((w, i) => (
        <mesh key={i} castShadow receiveShadow position={w.pos}>
          <boxGeometry args={w.size} />
          <meshStandardMaterial
            color={0x181820}
            metalness={0.6}
            roughness={0.35}
          />
        </mesh>
      ))}
      {/* Wall top edge glow strips */}
      {wallPositions.map((w, i) => (
        <mesh key={`edge-${i}`} position={[w.pos[0], 1.0, w.pos[2]]}>
          <boxGeometry args={[w.size[0], 0.03, w.size[2]]} />
          <meshStandardMaterial
            color={0x0066cc}
            emissive={0x0066cc}
            emissiveIntensity={0.8}
            metalness={0.4}
            roughness={0.4}
          />
        </mesh>
      ))}
    </group>
  );
}

function MazeFloor() {
  const gridTexture = useMemo(() => {
    const size = 512;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#0a0a12';
    ctx.fillRect(0, 0, size, size);

    const cells = GRID_COLS;
    const cellPx = size / cells;
    ctx.strokeStyle = '#003366';
    ctx.lineWidth = 2;
    for (let i = 0; i <= cells; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellPx, 0);
      ctx.lineTo(i * cellPx, size);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * cellPx);
      ctx.lineTo(size, i * cellPx);
      ctx.stroke();
    }

    // Add subtle glow nodes at intersections
    for (let r = 0; r < cells; r++) {
      for (let c = 0; c < cells; c++) {
        if (MAZE_GRID[r][c] === 0) {
          const cx = c * cellPx + cellPx / 2;
          const cy = r * cellPx + cellPx / 2;
          const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, cellPx * 0.3);
          grad.addColorStop(0, 'rgba(0,80,180,0.15)');
          grad.addColorStop(1, 'rgba(0,80,180,0)');
          ctx.fillStyle = grad;
          ctx.fillRect(c * cellPx, r * cellPx, cellPx, cellPx);
        }
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    return tex;
  }, []);

  const floorSize = GRID_COLS * CELL_SIZE;

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow position={[0, -0.01, 0]}>
      <planeGeometry args={[floorSize, floorSize]} />
      <meshStandardMaterial
        map={gridTexture}
        metalness={0.5}
        roughness={0.6}
        color={0x1a1a28}
      />
    </mesh>
  );
}

function SceneLights() {
  return (
    <>
      {/* Ambient base light - dim blue tint */}
      <ambientLight intensity={0.15} color={0x223388} />

      {/* Main directional light from top-front */}
      <directionalLight
        position={[8, 15, 6]}
        intensity={0.6}
        color={0xaaccff}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-15}
        shadow-camera-right={15}
        shadow-camera-top={15}
        shadow-camera-bottom={-15}
        shadow-camera-near={1}
        shadow-camera-far={40}
      />

      {/* Cyan rim light from left */}
      <directionalLight
        position={[-10, 8, -4]}
        intensity={0.3}
        color={0x00aaff}
      />

      {/* Warm fill from bottom for ground bounce */}
      <pointLight
        position={[0, -2, 0]}
        intensity={0.4}
        color={0x0044aa}
        distance={25}
      />

      {/* Spotlight following rover area from top */}
      <spotLight
        position={[0, 12, 0]}
        angle={0.6}
        penumbra={0.5}
        intensity={0.5}
        color={0x88bbff}
        distance={20}
      />
    </>
  );
}

interface MazeSceneProps {
  className?: string;
}

export default function MazeScene({ className }: MazeSceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={containerRef} className={className} style={{ width: '100%', height: '100%' }}>
      <Canvas
        shadows
        dpr={[1, 1.5]}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: 'high-performance',
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.1,
        }}
        camera={{ position: [0, 14, 12], fov: 45, near: 0.1, far: 100 }}
        onCreated={({ scene, gl }) => {
          scene.fog = new THREE.Fog(0x05050a, 18, 38);
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.1;
        }}
      >
        <SceneLights />
        <MazeFloor />
        <MazeWalls />
        <MazeRover />
      </Canvas>
    </div>
  );
}
