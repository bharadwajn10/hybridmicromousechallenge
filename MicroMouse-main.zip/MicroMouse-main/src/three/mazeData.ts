// Maze grid definition - 1 = wall, 0 = corridor
// 11 columns x 11 rows grid, cell size = 2 units
// Waypoints are corridor centers the rover drives through

export const CELL_SIZE = 2;
export const GRID_COLS = 11;
export const GRID_ROWS = 11;

// 0 = open corridor, 1 = wall
// Designed as a micromouse-style maze with corridors and turns
export const MAZE_GRID: number[][] = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
  [1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1],
  [1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1],
  [1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1],
  [1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1],
  [1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1],
  [1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
  [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

// Convert grid cell (col, row) to world coordinates
// Grid is centered at origin
export function cellToWorld(col: number, row: number): [number, number] {
  const x = (col - (GRID_COLS - 1) / 2) * CELL_SIZE;
  const z = (row - (GRID_ROWS - 1) / 2) * CELL_SIZE;
  return [x, z];
}

// Waypoints the rover follows - a continuous loop through corridors
// Each waypoint is [col, row] in grid coordinates
export const WAYPOINTS: [number, number][] = [
  [1, 1],
  [2, 1],
  [3, 1],
  [4, 1],
  [5, 1],
  [5, 2],
  [5, 3],
  [4, 3],
  [3, 3],
  [3, 4],
  [3, 5],
  [4, 5],
  [5, 5],
  [5, 4],
  [6, 4],
  [7, 4],
  [7, 5],
  [7, 6],
  [6, 6],
  [5, 6],
  [4, 6],
  [3, 6],
  [3, 7],
  [3, 8],
  [4, 8],
  [5, 8],
  [5, 9],
  [4, 9],
  [3, 9],
  [2, 9],
  [1, 9],
  [1, 8],
  [1, 7],
  [1, 6],
  [1, 5],
  [1, 4],
  [1, 3],
  [1, 2],
];
