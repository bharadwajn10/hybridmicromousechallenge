import { MessageSquare } from 'lucide-react';

const studentCoordinators = [
  { name: 'Dileep Bhardwaaj S', phone: '8867016193' },
  { name: 'Paladi Karthik', phone: '9247291023' },
  { name: 'Urmimala Das', phone: '7439762485' },
  { name: 'Aditya Sampath Kumar', phone: '8921745681' },
];

const facultyCoordinators = [
  { name: 'Dr. Supriya Devi', phone: '9742324524' },
  { name: 'Dr. Shamanth S', phone: '9741099192' },
];

function CoordinatorCard({ title, coordinators }: { title: string; coordinators: { name: string; phone: string }[] }) {
  return (
    <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10">
      <h2 className="text-xs font-semibold tracking-wider text-cyan-300 uppercase mb-4">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {coordinators.map((coordinator) => (
          <div key={coordinator.phone} className="rounded-xl bg-black/20 border border-white/5 p-3">
            <div className="text-sm font-medium text-white">{coordinator.name}</div>
            <a
              href={`tel:${coordinator.phone}`}
              className="mt-1 inline-block text-sm text-cyan-300 hover:text-cyan-200 transition-colors"
            >
              📞 {coordinator.phone}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Contact() {
  return (
    <div className="bg-[#0a0a12] text-white pt-24 pb-16 px-4 sm:px-6 lg:px-16 min-h-screen">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 rounded-full bg-cyan-500/10 border border-cyan-500/20">
            <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-semibold tracking-wide text-cyan-300 uppercase">Get In Touch</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight">
            Contact <span className="text-cyan-400">Us</span>
          </h1>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            Questions about events, registration, or sponsorship? We're here to help.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <CoordinatorCard title="Student Coordinators" coordinators={studentCoordinators} />
          <CoordinatorCard title="Faculty Coordinators" coordinators={facultyCoordinators} />
        </div>
      </div>
    </div>
  );
}
