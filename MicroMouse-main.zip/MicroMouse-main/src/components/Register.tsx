import { Trophy } from 'lucide-react';

export default function Register() {
  return (
    <div className="bg-[#0a0a12] text-white pt-24 pb-16 px-4 sm:px-6 lg:px-16 flex items-center justify-center min-h-screen">
      <div className="max-w-md w-full mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 rounded-full bg-cyan-500/10 border border-cyan-500/20">
            <Trophy className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-semibold tracking-wide text-cyan-300 uppercase">Join the Competition</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight">
            Register Your <span className="text-cyan-400">Team</span>
          </h1>
          <p className="mt-4 text-gray-400">
            Scan the QR code below to register for Alliance One.
          </p>
        </div>

        {/* QR Code Display */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
          <div className="flex justify-center mb-5">
            <div className="relative p-4 rounded-2xl bg-white">
              <img
                src="/images/WhatsApp_Image_2026-10-12_at_5.02.14_PM.jpeg"
                alt="Alliance One registration QR code"
                className="w-48 h-48 object-contain"
              />
              <div className="absolute inset-0 border-2 border-cyan-500/30 rounded-2xl pointer-events-none" />
            </div>
          </div>
          <p className="text-sm text-gray-400 mb-5">
            Place your registration QR code here. Open your camera or a QR scanner
            app to scan and fill out the registration form.
          </p>
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLSeV8q1C_SYbBQC7Ej9It_x_ubTKn_idEQpbg5a-ViS1kET-hw/viewform"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-600/5 border border-cyan-500/20 text-sm text-cyan-300"
          >
            Click Here to Register
          </a>
        </div>
      </div>
    </div>
  );
}
