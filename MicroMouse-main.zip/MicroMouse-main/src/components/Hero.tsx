import { lazy, Suspense } from 'react';
import { Calendar, Trophy, Zap, QrCode } from 'lucide-react';

const MazeScene = lazy(() => import('@/three/MazeScene'));

interface HeroProps {
  onNavigate: (page: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section className="relative w-full h-screen min-h-[700px] overflow-hidden bg-black">
      {/* 3D Maze Scene - right side, full background */}
      <div className="absolute inset-0 z-0">
        <Suspense fallback={<div className="w-full h-full bg-gradient-to-br from-black via-gray-950 to-blue-950/30" />}>
          <MazeScene className="w-full h-full" />
        </Suspense>
      </div>

      {/* Gradient overlay for text readability on left side */}
      <div className="absolute inset-0 z-10 pointer-events-none bg-gradient-to-r from-black via-black/85 to-transparent md:from-black/90 md:via-black/50 md:to-transparent" />
      <div className="absolute inset-0 z-10 pointer-events-none bg-gradient-to-t from-black/80 via-transparent to-black/40" />

      {/* Content */}
      <div className="relative z-20 flex flex-col justify-between h-full pt-20 pb-8 px-6 sm:px-10 lg:px-16">
        {/* Top: headline */}
        <div className="flex-1 flex flex-col justify-center max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-6 rounded-full bg-cyan-500/10 border border-cyan-500/20 backdrop-blur-sm w-fit">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-semibold tracking-wide text-cyan-300 uppercase">
              Hybrid Micromouse Edition
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.05] text-white">
            BUILD TODAY.
            <br />
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              AUTOMATE TOMORROW.
            </span>
          </h1>

          {/* Description */}
          <p className="mt-6 text-base sm:text-lg text-gray-400 max-w-lg leading-relaxed">
            Alliance One is the ultimate robotics festival where innovation meets
            automation. Build, code, and race autonomous rovers through
            high-stakes mazes for glory and a prize pool.
          </p>

          {/* Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => onNavigate('rules')}
              className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg shadow-cyan-500/25 hover:shadow-cyan-400/40 hover:scale-[1.02]"
            >
              <Calendar className="w-5 h-5" />
              Rules & Regulations
            </button>
            <button
              onClick={() => onNavigate('register')}
              className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-white/5 hover:bg-white/10 border border-cyan-500/20 hover:border-cyan-400/40 text-white font-semibold rounded-xl transition-all duration-200 backdrop-blur-sm"
            >
              <QrCode className="w-5 h-5 text-cyan-400" />
              Register Now
            </button>
          </div>
        </div>

        {/* Bottom-left stats */}
        <div className="flex items-end gap-4 sm:gap-6">
          <div className="flex flex-col gap-1 p-4 sm:p-5 rounded-2xl bg-black/60 backdrop-blur-md border border-cyan-500/15">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-semibold tracking-wider text-cyan-300 uppercase">
                Hybrid Micromouse
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-bold text-white leading-tight">
              <span className="text-cyan-400">₹55K</span> Prize Pool
            </div>
            <div className="text-xs text-gray-500">Total Prize Pool</div>
          </div>
        </div>
      </div>
    </section>
  );
}
