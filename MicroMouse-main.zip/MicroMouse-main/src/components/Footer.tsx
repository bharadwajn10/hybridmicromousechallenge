import { Cpu, Heart } from 'lucide-react';

export default function Footer({ onNavigate }: { onNavigate: (id: string) => void }) {
  return (
    <footer className="bg-black border-t border-cyan-500/10 px-6 py-8">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-cyan-400" />
          <span className="text-sm font-bold text-white">
            Alliance <span className="text-cyan-400">One</span>
          </span>
        </div>

        <nav className="flex flex-wrap items-center gap-4 text-xs text-gray-500">
          {[
            { label: 'Rules', id: 'rules' },
            { label: 'Register', id: 'register' },
            { label: 'Contact', id: 'contact' },
          ].map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className="hover:text-cyan-300 transition-colors"
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-1.5 text-xs text-gray-600">
          <span>Built with</span>
          <Heart className="w-3 h-3 text-cyan-400" />
          <span>by the Robotics Club</span>
        </div>
      </div>
    </footer>
  );
}
