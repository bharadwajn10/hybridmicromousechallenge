import { ScrollText, Users, Clock, Trophy, Cpu, CheckCircle2, GraduationCap, School, AlertTriangle } from 'lucide-react';

const RULE_CATEGORIES = [
  {
    icon: Users,
    title: 'Team Composition',
    rules: [
      'Each team must consist of 2 to 4 members.',
      'All team members must be current students of a recognized institution.',
      'A team member cannot be part of more than one team in the same event.',
      'A faculty mentor is optional but recommended.',
    ],
  },
  {
    icon: Cpu,
    title: 'Robot Specifications',
    rules: [
      'Maximum robot dimensions: 25cm x 25cm x 25cm.',
      'Maximum weight: 3 kg (including batteries).',
      'Power supply must not exceed 24V DC.',
      'No external power cords allowed during the run.',
      'Robots must be fully autonomous — no remote control during the maze run.',
    ],
  },
  {
    icon: Clock,
    title: 'Competition Format',
    rules: [
      'Each team gets two qualification runs and one final run.',
      'Maximum time per run is 5 minutes.',
      'A run ends when the robot reaches the destination or time expires.',
      'The shortest time across all runs determines the winner.',
      'Teams may modify their robot between runs but not during a run.',
    ],
  },
];

export default function Rules() {
  return (
    <div className="bg-[#0a0a12] text-white pt-24 pb-16 px-4 sm:px-6 lg:px-16">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 rounded-full bg-cyan-500/10 border border-cyan-500/20">
            <ScrollText className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-semibold tracking-wide text-cyan-300 uppercase">Competition Guidelines</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight">
            Rules & <span className="text-cyan-400">Regulations</span>
          </h1>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            Official rules for all Alliance One competitions. Please read carefully before registering your team.
          </p>
        </div>

        {/* Eligibility Criteria */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">Eligibility Criteria</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {/* School Level */}
            <div className="group rounded-2xl p-6 bg-gradient-to-br from-cyan-500/10 to-blue-600/5 border border-cyan-500/20 hover:border-cyan-400/40 transition-all duration-300">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-cyan-500/15 border border-cyan-500/25 flex items-center justify-center flex-shrink-0">
                  <School className="w-6 h-6 text-cyan-400" />
                </div>
                <h3 className="text-xl font-bold text-white">School Level</h3>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed">
                Open to students currently studying in Classes 9&ndash;12.
              </p>
            </div>

            {/* College Level */}
            <div className="group rounded-2xl p-6 bg-gradient-to-br from-blue-500/10 to-cyan-600/5 border border-blue-500/20 hover:border-blue-400/40 transition-all duration-300">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-blue-500/15 border border-blue-500/25 flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-xl font-bold text-white">College Level</h3>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed">
                Open to undergraduate (UG) students.
              </p>
            </div>
          </div>
        </div>

        {/* Rules grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {RULE_CATEGORIES.map((category, i) => (
            <div
              key={i}
              className="group rounded-2xl p-6 bg-white/[0.03] border border-white/10 hover:border-cyan-500/30 transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center flex-shrink-0">
                  <category.icon className="w-5 h-5 text-cyan-400" />
                </div>
                <h3 className="text-lg font-bold text-white">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.rules.map((rule, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm text-gray-400 leading-relaxed">
                    <CheckCircle2 className="w-4 h-4 text-cyan-500/50 flex-shrink-0 mt-0.5" />
                    <span>{rule}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Judging & Prizes — separate section */}
        <div className="mb-12">
          <div className="rounded-2xl bg-gradient-to-br from-cyan-500/10 to-blue-600/5 border border-cyan-500/20 p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-cyan-500/15 border border-cyan-500/25 flex items-center justify-center flex-shrink-0">
                <Trophy className="w-6 h-6 text-cyan-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Judging & Prizes</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-2.5 text-sm text-gray-300 leading-relaxed">
                <CheckCircle2 className="w-4 h-4 text-cyan-500/50 flex-shrink-0 mt-0.5" />
                <span>The top 3 teams receive cash prizes of ₹30K, ₹15K, and ₹10K respectively.</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-gray-300 leading-relaxed">
                <CheckCircle2 className="w-4 h-4 text-cyan-500/50 flex-shrink-0 mt-0.5" />
                <span>An additional "Best Design" award of ₹5K is given for the most innovative robot.</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-gray-300 leading-relaxed">
                <CheckCircle2 className="w-4 h-4 text-cyan-500/50 flex-shrink-0 mt-0.5" />
                <span>Judges evaluate based on completion time, accuracy, and design innovation.</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-gray-300 leading-relaxed">
                <CheckCircle2 className="w-4 h-4 text-cyan-500/50 flex-shrink-0 mt-0.5" />
                <span>All decisions by the judging panel are final and binding.</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-gray-300 leading-relaxed">
                <CheckCircle2 className="w-4 h-4 text-cyan-500/50 flex-shrink-0 mt-0.5" />
                <span>Prizes are distributed within 15 days of the event via bank transfer.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Important notice */}
        <div className="rounded-2xl bg-gradient-to-br from-amber-500/10 to-orange-600/5 border border-amber-500/20 p-6 sm:p-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-2">Important Notice</h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                By registering for Alliance One, all participants agree to abide by the rules
                stated above. The organizing committee reserves the right to modify rules
                at any time with prior notice. Any changes will be communicated to
                registered teams via email. Safety is our top priority — all robots must
                pass a safety inspection before being allowed to compete.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
