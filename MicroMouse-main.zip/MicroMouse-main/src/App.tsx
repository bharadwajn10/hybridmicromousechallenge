import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Rules from '@/components/Rules';
import Register from '@/components/Register';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

function App() {
  useEffect(() => {
    document.title = 'Alliance One — Build Today. Automate Tomorrow.';
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#05050a] text-white antialiased">
      <Navbar onNavigate={scrollToSection} />
      <main>
        <section id="home">
          <Hero onNavigate={scrollToSection} />
        </section>
        <section id="rules">
          <Rules />
        </section>
        <section id="register">
          <Register />
        </section>
        <section id="contact">
          <Contact />
        </section>
      </main>
      <Footer onNavigate={scrollToSection} />
    </div>
  );
}

export default App;
